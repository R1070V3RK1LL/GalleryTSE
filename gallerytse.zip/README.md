# GalleryTSE
Academic project for sharing and commenting on pictures

# Installation
You should have node installed and mongodb
```
npm install
cd client
npm install
```

# Usage
Create a database in mongodb and call it photos_db

run server
```
nodemon server.js
```
run client
```
cd client
npm run dev
```
