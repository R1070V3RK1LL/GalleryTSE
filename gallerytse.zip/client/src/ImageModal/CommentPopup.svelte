<script>
	import CommentComponent from './CommentComponent.svelte'
</script>

<style>

</style>



<CommentComponent />