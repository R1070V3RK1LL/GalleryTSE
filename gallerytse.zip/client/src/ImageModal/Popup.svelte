<script>
  import Slideshow from "./Slideshow.svelte";
</script>

<Slideshow />

<style>

</style>
